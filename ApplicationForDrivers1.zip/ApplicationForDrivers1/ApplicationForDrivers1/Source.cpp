/**********************************************************************
*  TEST_1
*  Dynamically Load a Driver
**********************************************************************/
#include <windows.h>
#include <stdio.h>
//#include "stdafx.h"

/*********************************************************
*   Main Function Entry
*********************************************************/
int _cdecl main(void)
{
	SC_HANDLE hSCManager;
	SC_HANDLE hService;
	SERVICE_STATUS ss;
	LPCSTR serviceModName;
	LPCSTR serviceDisplayName;
	LPCSTR dvrPath;
	hSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);

	serviceModName = "MSKrnlSvc";
	serviceDisplayName = "MS Kernel Service";
	dvrPath = "C:\\npf.sys";

	printf("[*] Loading Driver...\n");

	if (hSCManager)
	{
		printf("[+] SC Manager Opened\n");
		printf("[*] Creating Service...\n");
		hService = CreateService(hSCManager, serviceModName, serviceDisplayName, SERVICE_START | DELETE | SERVICE_STOP, SERVICE_KERNEL_DRIVER, SERVICE_DEMAND_START, SERVICE_ERROR_IGNORE, dvrPath, NULL, NULL, NULL, NULL, NULL);

		if (!hService)
		{	
			hService = OpenService(hSCManager, serviceModName, SERVICE_START | DELETE | SERVICE_STOP);
		} // end if
		if (hService == NULL) {
			printf("OpenService failed (%d) \n", GetLastError());
		} // end if
		else printf("[+] Service Created \n");
	
		if (hService)
		{
			StartService(hService, 0, NULL);
			printf("[+] Started Service: MSKrnlSvc \n");
			hService = OpenService(hSCManager, serviceModName, DELETE);
			ControlService(hService, SERVICE_CONTROL_STOP, &ss);

			if (CloseServiceHandle(hSCManager) == NULL) {
				printf("[-] Service Handle Close Failed... (%d) \n", GetLastError());

			} //end if
			else printf("[+] Handle to SC Manager closed \n");
						
			if (DeleteService(hService)) {
				printf("[+] Service Scheduled to be Deleted \n");
			} //end if
			else {
				printf("[-] Error Deleting Service \n");
			}
			if (CloseServiceHandle(hService)) {
				printf("[+] Service Handle Closed \n");
			}// end if
		} // end if	
	} // end if
	printf("Press Enter to close application & terminate Service \n");
	getchar();
	return 0;
}


